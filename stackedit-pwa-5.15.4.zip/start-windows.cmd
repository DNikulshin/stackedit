@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

rem Serve root = folder with sw.js and manifest*.json (and app\).
rem If the folder is nested (e.g. stackedit-pwa-5.15.4\stackedit-pwa after unpacking),
rem look 1-2 levels deep and use the matching folder.
set "ROOT="
call :check "%CD%"
if not defined ROOT for /d %%d in (*) do call :check "%%~fd"
if not defined ROOT for /d %%d in (*) do for /d %%e in ("%%~fd\*") do call :check "%%~fe"
if not defined ROOT goto :nofound

:run
cd /d "%ROOT%"
set "PORT=8080"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3 не найден. Установите его с https://python.org/downloads
  echo При установке отметьте галочку "Add python.exe to PATH", затем запустите этот файл снова.
  pause
  exit /b 1
)
echo.
echo Папка раздачи: %ROOT%
echo Адрес:         http://localhost:%PORT%/      (адрес /app/ — то же приложение)
echo Это окно должно оставаться открытым, пока вы работаете. Ctrl+C — остановить.
echo.
start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%/"
%PY% -m http.server %PORT%
exit /b 0

:check
if exist "%~1\sw.js" (
  for /f "delims=" %%m in ('dir /b "%~1\manifest*.json" 2^>nul') do (
    if not defined ROOT set "ROOT=%~1"
  )
)
exit /b 0

:nofound
echo.
echo Не нашёл файлы приложения ^(sw.js, manifest*.json, app^) ни в этой папке, ни рядом.
echo Распакуйте архив целиком и запустите этот файл из папки, где лежат sw.js и app.
echo.
pause
exit /b 1
