#!/usr/bin/env sh
# Запуск StackEdit локально: http://localhost:8080/
# Открывать index.html напрямую (file://) нельзя — приложение не загрузится.
cd "$(dirname "$0")" || exit 1

# Корень раздачи — папка с sw.js и manifest*.json (может быть вложенной после распаковки).
find_root() {
  for d in "$1" "$1"/* "$1"/*/*; do
    [ -d "$d" ] || continue
    [ -f "$d/sw.js" ] || continue
    set +f
    for m in "$d"/manifest*.json; do
      [ -f "$m" ] && { printf '%s\n' "$d"; return 0; }
    done
    set -f
  done
  return 1
}
ROOT="$(find_root "$(pwd)")" || {
  echo "Не нашёл sw.js и manifest*.json в текущей папке и рядом." >&2
  echo "Запустите скрипт из папки, где лежат sw.js, app и manifest*.json." >&2
  exit 1
}
cd "$ROOT" || exit 1

PORT="${PORT:-8080}"
PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then
  echo "Нужен Python 3 (python3 или python)." >&2
  exit 1
fi
echo "Папка раздачи: $ROOT"
echo "Адрес:         http://localhost:$PORT/   (и /app/ — то же приложение)"
echo "Ctrl+C — остановить."
( sleep 2; (command -v xdg-open >/dev/null && xdg-open "http://localhost:$PORT/") || \
            (command -v open >/dev/null && open "http://localhost:$PORT/") ) >/dev/null 2>&1 &
exec "$PY" -m http.server "$PORT"
